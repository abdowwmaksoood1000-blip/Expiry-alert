import React, { Component, ErrorInfo, ReactNode } from 'react';
import { AlertTriangle } from 'lucide-react';

interface Props {
  children?: ReactNode;
}

interface State {
  hasError: boolean;
  error: Error | null;
  errorInfo: ErrorInfo | null;
}

export class ErrorBoundary extends React.Component<Props, State> {
  public state: State = {
    hasError: false,
    error: null,
    errorInfo: null
  };

  public static getDerivedStateFromError(error: Error): State {
    return { hasError: true, error, errorInfo: null };
  }

  public componentDidCatch(error: Error, errorInfo: ErrorInfo) {
    console.error('Uncaught error:', error, errorInfo);
    this.setState({ errorInfo });
  }

  public render() {
    if (this.state.hasError) {
      let parsedError = null;
      try {
        if (this.state.error?.message.includes('{')) {
          parsedError = JSON.parse(this.state.error.message);
        }
      } catch (e) {
        // Not a JSON error
      }

      return (
        <div className="min-h-screen bg-neutral-50 flex items-center justify-center p-4">
          <div className="bg-white p-8 rounded-2xl shadow-sm border border-red-100 max-w-lg w-full">
            <div className="flex items-center gap-3 text-red-600 mb-4">
              <AlertTriangle className="w-8 h-8" />
              <h1 className="text-xl font-bold">Something went wrong</h1>
            </div>
            
            <p className="text-neutral-600 mb-6">
              An unexpected error occurred. Please try refreshing the page or contact support if the problem persists.
            </p>

            {parsedError ? (
              <div className="bg-red-50 p-4 rounded-xl border border-red-100 text-sm font-mono text-red-800 overflow-auto">
                <p className="font-bold mb-2">Firestore Permission Error:</p>
                <p>Operation: {parsedError.operationType}</p>
                <p>Path: {parsedError.path}</p>
                <p className="mt-2 text-xs opacity-80">{parsedError.error}</p>
              </div>
            ) : (
              <div className="bg-neutral-100 p-4 rounded-xl border border-neutral-200 text-sm font-mono text-neutral-800 overflow-auto">
                {this.state.error?.message || 'Unknown error'}
              </div>
            )}

            <button
              onClick={() => window.location.reload()}
              className="mt-6 w-full bg-neutral-900 hover:bg-neutral-800 text-white font-medium py-3 rounded-xl transition-colors"
            >
              Refresh Page
            </button>
          </div>
        </div>
      );
    }

    return this.props.children;
  }
}
