import React from 'react';
import { Outlet, Link, useLocation } from 'react-router-dom';
import { useAuth } from '../contexts/AuthContext';
import { Home, PlusCircle, Settings, LogOut, Package, BarChart3 } from 'lucide-react';
import { cn } from '../lib/utils';

export default function Layout() {
  const { logout } = useAuth();
  const location = useLocation();

  const navItems = [
    { name: 'Dashboard', path: '/', icon: Home },
    { name: 'Add Product', path: '/add', icon: PlusCircle },
    { name: 'Reports', path: '/reports', icon: BarChart3 },
    { name: 'Settings', path: '/settings', icon: Settings },
  ];

  return (
    <div className="min-h-screen bg-neutral-50 flex flex-col md:flex-row">
      {/* Mobile Header */}
      <header className="md:hidden bg-white border-b border-neutral-200 p-4 flex justify-between items-center sticky top-0 z-10">
        <div className="flex items-center gap-2 text-emerald-600 font-bold text-xl">
          <Package className="w-6 h-6" />
          ExpiryAlert
        </div>
        <button onClick={logout} className="text-neutral-500 p-2">
          <LogOut className="w-5 h-5" />
        </button>
      </header>

      {/* Sidebar (Desktop) */}
      <aside className="hidden md:flex flex-col w-64 bg-white border-r border-neutral-200 min-h-screen p-4 sticky top-0 h-screen">
        <div className="flex items-center gap-2 text-emerald-600 font-bold text-2xl mb-8 p-2">
          <Package className="w-8 h-8" />
          ExpiryAlert
        </div>
        
        <nav className="flex-1 space-y-2">
          {navItems.map((item) => {
            const Icon = item.icon;
            const isActive = location.pathname === item.path;
            return (
              <Link
                key={item.path}
                to={item.path}
                className={cn(
                  "flex items-center gap-3 px-4 py-3 rounded-xl transition-colors font-medium",
                  isActive 
                    ? "bg-emerald-50 text-emerald-700" 
                    : "text-neutral-600 hover:bg-neutral-100"
                )}
              >
                <Icon className="w-5 h-5" />
                {item.name}
              </Link>
            );
          })}
        </nav>

        <button 
          onClick={logout}
          className="flex items-center gap-3 px-4 py-3 rounded-xl text-neutral-600 hover:bg-red-50 hover:text-red-600 transition-colors font-medium mt-auto"
        >
          <LogOut className="w-5 h-5" />
          Sign Out
        </button>
      </aside>

      {/* Main Content */}
      <main className="flex-1 p-4 md:p-8 pb-24 md:pb-8 max-w-5xl mx-auto w-full">
        <Outlet />
      </main>

      {/* Mobile Bottom Nav */}
      <nav className="md:hidden fixed bottom-0 left-0 right-0 bg-white border-t border-neutral-200 flex justify-around p-2 pb-safe z-10">
        {navItems.map((item) => {
          const Icon = item.icon;
          const isActive = location.pathname === item.path;
          return (
            <Link
              key={item.path}
              to={item.path}
              className={cn(
                "flex flex-col items-center p-2 rounded-lg min-w-[64px]",
                isActive ? "text-emerald-600" : "text-neutral-500"
              )}
            >
              <Icon className={cn("w-6 h-6 mb-1", isActive && "fill-emerald-100")} />
              <span className="text-[10px] font-medium">{item.name}</span>
            </Link>
          );
        })}
      </nav>
    </div>
  );
}
