import React, { useEffect, useState } from 'react';
import { useAuth } from '../contexts/AuthContext';
import { db } from '../firebase';
import { collection, query, where, onSnapshot, orderBy } from 'firebase/firestore';
import { differenceInDays, parseISO, format } from 'date-fns';
import { AlertTriangle, Clock, DollarSign, Package, CheckCircle2 } from 'lucide-react';
import { cn } from '../lib/utils';
import { Link } from 'react-router-dom';
import { handleFirestoreError, OperationType } from '../lib/firestore-errors';

interface Product {
  id: string;
  name: string;
  category: string;
  quantity: number;
  cost_per_unit: number;
  expiry_date: string;
  status: string;
}

export default function Dashboard() {
  const { user } = useAuth();
  const [products, setProducts] = useState<Product[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!user) return;

    const q = query(
      collection(db, 'products'),
      where('user_id', '==', user.uid),
      where('status', '==', 'active'),
      orderBy('expiry_date', 'asc')
    );

    const unsubscribe = onSnapshot(q, (snapshot) => {
      const productsData = snapshot.docs.map(doc => ({
        id: doc.id,
        ...doc.data()
      })) as Product[];
      setProducts(productsData);
      setLoading(false);
    }, (error) => {
      setLoading(false);
      handleFirestoreError(error, OperationType.LIST, 'products');
    });

    return unsubscribe;
  }, [user]);

  const today = new Date();
  
  const expiringIn7Days = products.filter(p => differenceInDays(parseISO(p.expiry_date), today) <= 7);
  const expiringIn30Days = products.filter(p => {
    const days = differenceInDays(parseISO(p.expiry_date), today);
    return days > 7 && days <= 30;
  });

  const value7Days = expiringIn7Days.reduce((acc, p) => acc + (p.quantity * p.cost_per_unit), 0);
  const value30Days = expiringIn30Days.reduce((acc, p) => acc + (p.quantity * p.cost_per_unit), 0);
  const totalValue = products.reduce((acc, p) => acc + (p.quantity * p.cost_per_unit), 0);

  const getStatusColor = (expiryDate: string) => {
    const days = differenceInDays(parseISO(expiryDate), today);
    if (days <= 7) return 'bg-red-100 text-red-700 border-red-200';
    if (days <= 30) return 'bg-amber-100 text-amber-700 border-amber-200';
    return 'bg-emerald-100 text-emerald-700 border-emerald-200';
  };

  const getStatusIcon = (expiryDate: string) => {
    const days = differenceInDays(parseISO(expiryDate), today);
    if (days <= 7) return <AlertTriangle className="w-4 h-4" />;
    if (days <= 30) return <Clock className="w-4 h-4" />;
    return <CheckCircle2 className="w-4 h-4" />;
  };

  if (loading) {
    return <div className="flex justify-center items-center h-64">Loading...</div>;
  }

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h1 className="text-2xl font-bold text-neutral-900">Dashboard</h1>
        <Link to="/add" className="bg-emerald-600 hover:bg-emerald-700 text-white px-4 py-2 rounded-xl font-medium transition-colors shadow-sm text-sm">
          + Add Product
        </Link>
      </div>

      {/* Summary Cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <div className="bg-white p-5 rounded-2xl border border-red-100 shadow-sm relative overflow-hidden">
          <div className="absolute top-0 right-0 p-4 opacity-10"><AlertTriangle className="w-16 h-16 text-red-500"/></div>
          <h3 className="text-sm font-medium text-red-600 mb-1">Expiring in ≤ 7 Days</h3>
          <div className="text-3xl font-bold text-neutral-900 mb-1">{expiringIn7Days.length} items</div>
          <div className="text-sm text-neutral-500 font-medium">${value7Days.toFixed(2)} at risk</div>
        </div>
        
        <div className="bg-white p-5 rounded-2xl border border-amber-100 shadow-sm relative overflow-hidden">
          <div className="absolute top-0 right-0 p-4 opacity-10"><Clock className="w-16 h-16 text-amber-500"/></div>
          <h3 className="text-sm font-medium text-amber-600 mb-1">Expiring in 8-30 Days</h3>
          <div className="text-3xl font-bold text-neutral-900 mb-1">{expiringIn30Days.length} items</div>
          <div className="text-sm text-neutral-500 font-medium">${value30Days.toFixed(2)} at risk</div>
        </div>

        <div className="bg-white p-5 rounded-2xl border border-neutral-200 shadow-sm relative overflow-hidden">
          <div className="absolute top-0 right-0 p-4 opacity-5"><DollarSign className="w-16 h-16 text-neutral-900"/></div>
          <h3 className="text-sm font-medium text-neutral-500 mb-1">Total Inventory Value</h3>
          <div className="text-3xl font-bold text-neutral-900 mb-1">${totalValue.toFixed(2)}</div>
          <div className="text-sm text-neutral-500 font-medium">{products.length} active items</div>
        </div>
      </div>

      {/* Product List */}
      <div className="bg-white rounded-2xl border border-neutral-200 shadow-sm overflow-hidden">
        <div className="px-5 py-4 border-b border-neutral-200 bg-neutral-50/50">
          <h2 className="font-semibold text-neutral-900">Expiring Soon</h2>
        </div>
        
        {products.length === 0 ? (
          <div className="p-8 text-center text-neutral-500">
            <Package className="w-12 h-12 mx-auto mb-3 text-neutral-300" />
            <p>No active products found.</p>
            <Link to="/add" className="text-emerald-600 font-medium hover:underline mt-2 inline-block">Add your first product</Link>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left text-sm">
              <thead className="bg-neutral-50 text-neutral-500 uppercase text-xs font-semibold">
                <tr>
                  <th className="px-5 py-3">Product</th>
                  <th className="px-5 py-3">Category</th>
                  <th className="px-5 py-3">Qty</th>
                  <th className="px-5 py-3">Value</th>
                  <th className="px-5 py-3">Expiry</th>
                  <th className="px-5 py-3 text-right">Action</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-neutral-100">
                {products.map((product) => {
                  const days = differenceInDays(parseISO(product.expiry_date), today);
                  return (
                    <tr key={product.id} className="hover:bg-neutral-50 transition-colors">
                      <td className="px-5 py-4 font-medium text-neutral-900">{product.name}</td>
                      <td className="px-5 py-4 text-neutral-500">{product.category}</td>
                      <td className="px-5 py-4 text-neutral-900">{product.quantity}</td>
                      <td className="px-5 py-4 text-neutral-500">${(product.quantity * product.cost_per_unit).toFixed(2)}</td>
                      <td className="px-5 py-4">
                        <div className={cn(
                          "inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-semibold border",
                          getStatusColor(product.expiry_date)
                        )}>
                          {getStatusIcon(product.expiry_date)}
                          {days < 0 ? 'Expired' : `${days} days`}
                        </div>
                        <div className="text-[10px] text-neutral-400 mt-1 ml-1">{format(parseISO(product.expiry_date), 'MMM d, yyyy')}</div>
                      </td>
                      <td className="px-5 py-4 text-right">
                        <Link to={`/action/${product.id}`} className="text-emerald-600 hover:text-emerald-700 font-medium text-sm bg-emerald-50 hover:bg-emerald-100 px-3 py-1.5 rounded-lg transition-colors">
                          Log Action
                        </Link>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
}
