import React from 'react';
import { useAuth } from '../contexts/AuthContext';
import { Package, ShieldCheck, TrendingUp, BellRing } from 'lucide-react';

export default function Login() {
  const { signInWithGoogle } = useAuth();

  return (
    <div className="min-h-screen bg-neutral-50 flex flex-col justify-center py-12 sm:px-6 lg:px-8">
      <div className="sm:mx-auto sm:w-full sm:max-w-md text-center">
        <div className="flex justify-center mb-6">
          <div className="bg-emerald-100 p-4 rounded-full">
            <Package className="w-12 h-12 text-emerald-600" />
          </div>
        </div>
        <h2 className="mt-6 text-center text-3xl font-extrabold text-neutral-900 tracking-tight">
          ExpiryAlert
        </h2>
        <p className="mt-2 text-center text-sm text-neutral-600 max-w-xs mx-auto">
          Turn waste into profit. Track inventory freshness and get alerts before items expire.
        </p>
      </div>

      <div className="mt-8 sm:mx-auto sm:w-full sm:max-w-md">
        <div className="bg-white py-8 px-4 shadow-sm sm:rounded-2xl sm:px-10 border border-neutral-100">
          
          <div className="space-y-6">
            <div className="flex items-start gap-3">
              <div className="bg-red-50 p-2 rounded-lg text-red-600 mt-1"><BellRing className="w-5 h-5"/></div>
              <div>
                <h3 className="font-semibold text-neutral-900">Never miss an expiry</h3>
                <p className="text-sm text-neutral-500">Get notified 30, 14, and 7 days before items go bad.</p>
              </div>
            </div>
            
            <div className="flex items-start gap-3">
              <div className="bg-emerald-50 p-2 rounded-lg text-emerald-600 mt-1"><TrendingUp className="w-5 h-5"/></div>
              <div>
                <h3 className="font-semibold text-neutral-900">Recover lost revenue</h3>
                <p className="text-sm text-neutral-500">Discount or donate items in time instead of throwing them away.</p>
              </div>
            </div>

            <div className="flex items-start gap-3">
              <div className="bg-blue-50 p-2 rounded-lg text-blue-600 mt-1"><ShieldCheck className="w-5 h-5"/></div>
              <div>
                <h3 className="font-semibold text-neutral-900">Simple & secure</h3>
                <p className="text-sm text-neutral-500">Mobile-first design built for busy store owners.</p>
              </div>
            </div>
          </div>

          <div className="mt-8">
            <button
              onClick={signInWithGoogle}
              className="w-full flex justify-center items-center gap-3 py-3 px-4 border border-neutral-300 rounded-xl shadow-sm bg-white text-sm font-medium text-neutral-700 hover:bg-neutral-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-emerald-500 transition-colors"
            >
              <svg className="w-5 h-5" viewBox="0 0 24 24">
                <path
                  d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"
                  fill="#4285F4"
                />
                <path
                  d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"
                  fill="#34A853"
                />
                <path
                  d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z"
                  fill="#FBBC05"
                />
                <path
                  d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z"
                  fill="#EA4335"
                />
              </svg>
              Sign in with Google
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
