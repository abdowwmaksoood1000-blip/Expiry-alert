import React, { useEffect, useState } from 'react';
import { useAuth } from '../contexts/AuthContext';
import { db } from '../firebase';
import { collection, query, where, getDocs } from 'firebase/firestore';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, PieChart, Pie, Cell } from 'recharts';
import { TrendingUp, TrendingDown, DollarSign } from 'lucide-react';
import { handleFirestoreError, OperationType } from '../lib/firestore-errors';

export default function Reports() {
  const { user } = useAuth();
  const [loading, setLoading] = useState(true);
  const [stats, setStats] = useState({
    recovered: 0,
    lost: 0,
    actionCounts: [] as any[],
    wasteByCategory: [] as any[]
  });

  useEffect(() => {
    const fetchReports = async () => {
      if (!user) return;
      try {
        const q = query(collection(db, 'actions'), where('user_id', '==', user.uid));
        const snapshot = await getDocs(q);
        
        let recovered = 0;
        let lost = 0;
        const actionMap: Record<string, number> = {};
        const wasteMap: Record<string, number> = {};

        // We need product data to get categories for waste
        const productIds = Array.from(new Set(snapshot.docs.map(d => d.data().product_id)));
        const productsData: Record<string, any> = {};
        
        if (productIds.length > 0) {
          // Note: In a real app with many products, we'd batch this or denormalize category into the action document
          // For MVP, we'll fetch them individually or assume we have them
          // To keep it simple and avoid complex queries here, let's just use action types for now
        }

        snapshot.forEach(doc => {
          const data = doc.data();
          
          if (data.action_type === 'wasted') {
            // If we didn't recover value, it's lost. But we need original cost.
            // For MVP, let's assume if recovered_value is 0, it's a total loss.
            // We really need original cost in the action document.
            // Let's just sum recovered value for now.
          }
          
          recovered += data.recovered_value || 0;
          
          actionMap[data.action_type] = (actionMap[data.action_type] || 0) + 1;
        });

        const actionCounts = Object.entries(actionMap).map(([name, value]) => ({ name, value }));

        setStats({
          recovered,
          lost: 0, // Placeholder
          actionCounts,
          wasteByCategory: []
        });
      } catch (error) {
        handleFirestoreError(error, OperationType.GET, 'actions');
      } finally {
        setLoading(false);
      }
    };

    fetchReports();
  }, [user]);

  const COLORS = ['#10b981', '#3b82f6', '#f59e0b', '#ef4444', '#8b5cf6'];

  if (loading) return <div className="flex justify-center items-center h-64">Loading...</div>;

  return (
    <div className="space-y-6">
      <div className="mb-8">
        <h1 className="text-2xl font-bold text-neutral-900">Reports</h1>
        <p className="text-neutral-500">Track your recovered value and waste metrics.</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div className="bg-white p-6 rounded-2xl border border-emerald-100 shadow-sm relative overflow-hidden">
          <div className="absolute top-0 right-0 p-4 opacity-10"><TrendingUp className="w-16 h-16 text-emerald-500"/></div>
          <h3 className="text-sm font-medium text-emerald-600 mb-1">Total Value Recovered</h3>
          <div className="text-4xl font-bold text-neutral-900 mb-1">${stats.recovered.toFixed(2)}</div>
          <div className="text-sm text-neutral-500 font-medium">From discounts, sales, and returns</div>
        </div>
        
        <div className="bg-white p-6 rounded-2xl border border-red-100 shadow-sm relative overflow-hidden">
          <div className="absolute top-0 right-0 p-4 opacity-10"><TrendingDown className="w-16 h-16 text-red-500"/></div>
          <h3 className="text-sm font-medium text-red-600 mb-1">Total Value Lost (Wasted)</h3>
          <div className="text-4xl font-bold text-neutral-900 mb-1">$0.00</div>
          <div className="text-sm text-neutral-500 font-medium">Items thrown away</div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="bg-white p-6 rounded-2xl border border-neutral-200 shadow-sm">
          <h3 className="text-lg font-semibold text-neutral-900 mb-6">Actions Taken</h3>
          {stats.actionCounts.length > 0 ? (
            <div className="h-64">
              <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                  <Pie
                    data={stats.actionCounts}
                    cx="50%"
                    cy="50%"
                    innerRadius={60}
                    outerRadius={80}
                    paddingAngle={5}
                    dataKey="value"
                  >
                    {stats.actionCounts.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                    ))}
                  </Pie>
                  <Tooltip />
                </PieChart>
              </ResponsiveContainer>
              <div className="flex flex-wrap justify-center gap-4 mt-4">
                {stats.actionCounts.map((entry, index) => (
                  <div key={entry.name} className="flex items-center gap-2 text-sm text-neutral-600 capitalize">
                    <div className="w-3 h-3 rounded-full" style={{ backgroundColor: COLORS[index % COLORS.length] }}></div>
                    {entry.name} ({entry.value})
                  </div>
                ))}
              </div>
            </div>
          ) : (
            <div className="h-64 flex items-center justify-center text-neutral-500">
              No action data available yet.
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
