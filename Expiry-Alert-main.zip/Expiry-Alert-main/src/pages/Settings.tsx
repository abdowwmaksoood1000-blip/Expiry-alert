import React, { useEffect, useState } from 'react';
import { useAuth } from '../contexts/AuthContext';
import { db } from '../firebase';
import { doc, getDoc, updateDoc } from 'firebase/firestore';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import * as z from 'zod';
import { Loader2, Store, Clock, DollarSign, Shield, Mail, Smartphone } from 'lucide-react';
import { handleFirestoreError, OperationType } from '../lib/firestore-errors';

const settingsSchema = z.object({
  store_name: z.string().min(1, 'Store name is required'),
  timezone: z.string().min(1, 'Timezone is required'),
  currency: z.string().min(1, 'Currency is required'),
});

type SettingsFormValues = z.infer<typeof settingsSchema>;

export default function Settings() {
  const { user } = useAuth();
  const [loading, setLoading] = useState(true);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [subscriptionTier, setSubscriptionTier] = useState('free');

  const { register, handleSubmit, reset, formState: { errors, isDirty } } = useForm<SettingsFormValues>({
    resolver: zodResolver(settingsSchema),
  });

  useEffect(() => {
    const fetchSettings = async () => {
      if (!user) return;
      try {
        const docRef = doc(db, 'users', user.uid);
        const docSnap = await getDoc(docRef);
        if (docSnap.exists()) {
          const data = docSnap.data();
          reset({
            store_name: data.store_name || '',
            timezone: data.timezone || Intl.DateTimeFormat().resolvedOptions().timeZone,
            currency: data.currency || 'USD',
          });
          setSubscriptionTier(data.subscription_tier || 'free');
        }
      } catch (error) {
        handleFirestoreError(error, OperationType.GET, `users/${user.uid}`);
      } finally {
        setLoading(false);
      }
    };
    fetchSettings();
  }, [user, reset]);

  const onSubmit = async (data: SettingsFormValues) => {
    if (!user) return;
    setIsSubmitting(true);
    try {
      await updateDoc(doc(db, 'users', user.uid), {
        ...data,
      });
      alert("Settings saved successfully!");
    } catch (error) {
      handleFirestoreError(error, OperationType.UPDATE, `users/${user.uid}`);
    } finally {
      setIsSubmitting(false);
    }
  };

  if (loading) return <div className="flex justify-center items-center h-64">Loading...</div>;

  return (
    <div className="max-w-3xl mx-auto space-y-8">
      <div>
        <h1 className="text-2xl font-bold text-neutral-900">Settings</h1>
        <p className="text-neutral-500">Manage your store preferences and alerts.</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
        <div className="md:col-span-1">
          <h3 className="text-lg font-semibold text-neutral-900 mb-1">Store Profile</h3>
          <p className="text-sm text-neutral-500">Update your store details and localization settings.</p>
        </div>
        
        <div className="md:col-span-2 bg-white rounded-2xl border border-neutral-200 shadow-sm p-6">
          <form onSubmit={handleSubmit(onSubmit)} className="space-y-5">
            <div>
              <label className="flex items-center gap-2 text-sm font-medium text-neutral-700 mb-1">
                <Store className="w-4 h-4 text-neutral-400" /> Store Name
              </label>
              <input
                {...register('store_name')}
                className="w-full px-4 py-2 border border-neutral-300 rounded-xl focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500 outline-none transition-all"
              />
              {errors.store_name && <p className="text-red-500 text-xs mt-1">{errors.store_name.message}</p>}
            </div>

            <div className="grid grid-cols-2 gap-5">
              <div>
                <label className="flex items-center gap-2 text-sm font-medium text-neutral-700 mb-1">
                  <Clock className="w-4 h-4 text-neutral-400" /> Timezone
                </label>
                <select
                  {...register('timezone')}
                  className="w-full px-4 py-2 border border-neutral-300 rounded-xl focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500 outline-none transition-all bg-white"
                >
                  <option value="America/New_York">Eastern Time (ET)</option>
                  <option value="America/Chicago">Central Time (CT)</option>
                  <option value="America/Denver">Mountain Time (MT)</option>
                  <option value="America/Los_Angeles">Pacific Time (PT)</option>
                  <option value="UTC">UTC</option>
                  <option value="Europe/London">London (GMT/BST)</option>
                </select>
              </div>

              <div>
                <label className="flex items-center gap-2 text-sm font-medium text-neutral-700 mb-1">
                  <DollarSign className="w-4 h-4 text-neutral-400" /> Currency
                </label>
                <select
                  {...register('currency')}
                  className="w-full px-4 py-2 border border-neutral-300 rounded-xl focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500 outline-none transition-all bg-white"
                >
                  <option value="USD">USD ($)</option>
                  <option value="EUR">EUR (€)</option>
                  <option value="GBP">GBP (£)</option>
                  <option value="CAD">CAD ($)</option>
                  <option value="AUD">AUD ($)</option>
                </select>
              </div>
            </div>

            <div className="pt-4 flex justify-end">
              <button
                type="submit"
                disabled={!isDirty || isSubmitting}
                className="px-6 py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white font-medium rounded-xl transition-colors shadow-sm disabled:opacity-50 flex items-center gap-2"
              >
                {isSubmitting && <Loader2 className="w-4 h-4 animate-spin" />}
                Save Changes
              </button>
            </div>
          </form>
        </div>
      </div>

      <div className="border-t border-neutral-200 my-8"></div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
        <div className="md:col-span-1">
          <h3 className="text-lg font-semibold text-neutral-900 mb-1">Alert Preferences</h3>
          <p className="text-sm text-neutral-500">Choose how you want to be notified about expiring products.</p>
        </div>
        
        <div className="md:col-span-2 bg-white rounded-2xl border border-neutral-200 shadow-sm p-6 space-y-6">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="bg-emerald-50 p-2 rounded-lg"><Mail className="w-5 h-5 text-emerald-600" /></div>
              <div>
                <h4 className="font-medium text-neutral-900">Email Alerts</h4>
                <p className="text-sm text-neutral-500">Receive daily summaries at 8 AM.</p>
              </div>
            </div>
            <div className="relative inline-block w-12 mr-2 align-middle select-none transition duration-200 ease-in">
              <input type="checkbox" name="toggle" id="toggle1" checked readOnly className="toggle-checkbox absolute block w-6 h-6 rounded-full bg-white border-4 appearance-none cursor-pointer border-emerald-500 right-0" style={{ right: 0, borderColor: '#10b981' }}/>
              <label htmlFor="toggle1" className="toggle-label block overflow-hidden h-6 rounded-full bg-emerald-500 cursor-pointer"></label>
            </div>
          </div>

          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="bg-neutral-100 p-2 rounded-lg"><Smartphone className="w-5 h-5 text-neutral-500" /></div>
              <div>
                <h4 className="font-medium text-neutral-900 flex items-center gap-2">
                  SMS Alerts
                  {subscriptionTier === 'free' && <span className="text-[10px] uppercase font-bold bg-amber-100 text-amber-700 px-2 py-0.5 rounded-full">Pro</span>}
                </h4>
                <p className="text-sm text-neutral-500">Get text messages for urgent (7-day) alerts.</p>
              </div>
            </div>
            <div className="relative inline-block w-12 mr-2 align-middle select-none transition duration-200 ease-in opacity-50">
              <input type="checkbox" name="toggle" id="toggle2" disabled className="toggle-checkbox absolute block w-6 h-6 rounded-full bg-white border-4 appearance-none cursor-not-allowed border-neutral-300 left-0" />
              <label htmlFor="toggle2" className="toggle-label block overflow-hidden h-6 rounded-full bg-neutral-300 cursor-not-allowed"></label>
            </div>
          </div>
        </div>
      </div>

      <div className="border-t border-neutral-200 my-8"></div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
        <div className="md:col-span-1">
          <h3 className="text-lg font-semibold text-neutral-900 mb-1">Subscription</h3>
          <p className="text-sm text-neutral-500">Manage your billing and plan.</p>
        </div>
        
        <div className="md:col-span-2 bg-white rounded-2xl border border-neutral-200 shadow-sm p-6">
          <div className="flex items-center justify-between mb-6">
            <div className="flex items-center gap-3">
              <div className="bg-emerald-50 p-2 rounded-lg"><Shield className="w-5 h-5 text-emerald-600" /></div>
              <div>
                <h4 className="font-medium text-neutral-900 capitalize">{subscriptionTier} Plan</h4>
                <p className="text-sm text-neutral-500">
                  {subscriptionTier === 'free' ? 'Up to 50 products. Email alerts only.' : 'Unlimited products. SMS alerts included.'}
                </p>
              </div>
            </div>
            <div className="text-right">
              <div className="text-2xl font-bold text-neutral-900">{subscriptionTier === 'free' ? '$0' : '$29'}</div>
              <div className="text-sm text-neutral-500">per month</div>
            </div>
          </div>

          {subscriptionTier === 'free' && (
            <button className="w-full py-3 bg-neutral-900 hover:bg-neutral-800 text-white font-medium rounded-xl transition-colors shadow-sm">
              Upgrade to Pro
            </button>
          )}
        </div>
      </div>
    </div>
  );
}
