import React, { useEffect, useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { useAuth } from '../contexts/AuthContext';
import { db } from '../firebase';
import { doc, getDoc, updateDoc, addDoc, collection } from 'firebase/firestore';
import { ArrowLeft, Loader2, Tag, Heart, RotateCcw, DollarSign, Trash2 } from 'lucide-react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import * as z from 'zod';
import { handleFirestoreError, OperationType } from '../lib/firestore-errors';

const actionSchema = z.object({
  action_type: z.enum(['discounted', 'donated', 'returned', 'sold', 'wasted']),
  recovered_value: z.number().min(0, 'Value must be 0 or greater'),
  notes: z.string().optional(),
});

type ActionFormValues = z.infer<typeof actionSchema>;

export default function LogAction() {
  const { id } = useParams<{ id: string }>();
  const { user } = useAuth();
  const navigate = useNavigate();
  const [product, setProduct] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const [isSubmitting, setIsSubmitting] = useState(false);

  const { register, handleSubmit, watch, setValue, formState: { errors } } = useForm<ActionFormValues>({
    resolver: zodResolver(actionSchema),
    defaultValues: {
      action_type: 'discounted',
      recovered_value: 0,
    }
  });

  const actionType = watch('action_type');

  useEffect(() => {
    const fetchProduct = async () => {
      if (!id || !user) return;
      try {
        const docRef = doc(db, 'products', id);
        const docSnap = await getDoc(docRef);
        if (docSnap.exists() && docSnap.data().user_id === user.uid) {
          setProduct(docSnap.data());
          // Pre-fill recovered value based on action type
          setValue('recovered_value', docSnap.data().cost_per_unit * docSnap.data().quantity);
        } else {
          navigate('/');
        }
      } catch (error) {
        handleFirestoreError(error, OperationType.GET, `products/${id}`);
      } finally {
        setLoading(false);
      }
    };
    fetchProduct();
  }, [id, user, navigate, setValue]);

  // Auto-update recovered value when action type changes
  useEffect(() => {
    if (!product) return;
    const totalCost = product.cost_per_unit * product.quantity;
    
    switch (actionType) {
      case 'discounted':
        setValue('recovered_value', totalCost * 0.5); // Default 50% discount
        break;
      case 'donated':
      case 'wasted':
        setValue('recovered_value', 0);
        break;
      case 'returned':
      case 'sold':
        setValue('recovered_value', totalCost);
        break;
    }
  }, [actionType, product, setValue]);

  const onSubmit = async (data: ActionFormValues) => {
    if (!user || !id) return;
    setIsSubmitting(true);
    try {
      // 1. Add action log
      await addDoc(collection(db, 'actions'), {
        ...data,
        product_id: id,
        user_id: user.uid,
        action_date: new Date().toISOString(),
      });

      // 2. Update product status
      await updateDoc(doc(db, 'products', id), {
        status: 'actioned',
        updated_at: new Date().toISOString(),
      });

      navigate('/');
    } catch (error) {
      handleFirestoreError(error, OperationType.WRITE, `actions or products/${id}`);
    } finally {
      setIsSubmitting(false);
    }
  };

  if (loading) return <div className="flex justify-center items-center h-64">Loading...</div>;
  if (!product) return null;

  const totalValue = product.quantity * product.cost_per_unit;

  return (
    <div className="max-w-xl mx-auto">
      <button 
        onClick={() => navigate('/')}
        className="flex items-center gap-2 text-neutral-500 hover:text-neutral-900 mb-6 transition-colors"
      >
        <ArrowLeft className="w-4 h-4" /> Back to Dashboard
      </button>

      <div className="mb-8">
        <h1 className="text-2xl font-bold text-neutral-900">Log Action</h1>
        <p className="text-neutral-500">What happened to <span className="font-semibold text-neutral-900">{product.name}</span>?</p>
      </div>

      <div className="bg-white rounded-2xl border border-neutral-200 shadow-sm p-6">
        <div className="bg-neutral-50 p-4 rounded-xl mb-6 border border-neutral-100">
          <div className="flex justify-between items-center mb-2">
            <span className="text-sm text-neutral-500">Quantity</span>
            <span className="font-medium">{product.quantity} units</span>
          </div>
          <div className="flex justify-between items-center">
            <span className="text-sm text-neutral-500">Total Cost Value</span>
            <span className="font-medium">${totalValue.toFixed(2)}</span>
          </div>
        </div>

        <form onSubmit={handleSubmit(onSubmit)} className="space-y-6">
          <div>
            <label className="block text-sm font-medium text-neutral-700 mb-3">Action Taken</label>
            <div className="grid grid-cols-2 gap-3">
              {[
                { id: 'discounted', label: 'Discounted', icon: Tag, color: 'text-blue-600', bg: 'bg-blue-50', border: 'border-blue-200' },
                { id: 'donated', label: 'Donated', icon: Heart, color: 'text-emerald-600', bg: 'bg-emerald-50', border: 'border-emerald-200' },
                { id: 'returned', label: 'Returned', icon: RotateCcw, color: 'text-amber-600', bg: 'bg-amber-50', border: 'border-amber-200' },
                { id: 'sold', label: 'Sold (Full Price)', icon: DollarSign, color: 'text-emerald-600', bg: 'bg-emerald-50', border: 'border-emerald-200' },
                { id: 'wasted', label: 'Wasted/Thrown Out', icon: Trash2, color: 'text-red-600', bg: 'bg-red-50', border: 'border-red-200' },
              ].map((action) => {
                const Icon = action.icon;
                const isSelected = actionType === action.id;
                return (
                  <label 
                    key={action.id}
                    className={`
                      relative flex flex-col items-center p-4 cursor-pointer rounded-xl border-2 transition-all
                      ${isSelected ? `${action.border} ${action.bg}` : 'border-neutral-200 hover:border-neutral-300 bg-white'}
                      ${action.id === 'wasted' ? 'col-span-2' : ''}
                    `}
                  >
                    <input 
                      type="radio" 
                      value={action.id} 
                      {...register('action_type')} 
                      className="sr-only" 
                    />
                    <Icon className={`w-6 h-6 mb-2 ${isSelected ? action.color : 'text-neutral-400'}`} />
                    <span className={`text-sm font-medium ${isSelected ? 'text-neutral-900' : 'text-neutral-600'}`}>
                      {action.label}
                    </span>
                  </label>
                );
              })}
            </div>
          </div>

          <div>
            <label className="block text-sm font-medium text-neutral-700 mb-1">Recovered Value ($)</label>
            <p className="text-xs text-neutral-500 mb-2">How much money did you get back?</p>
            <input
              type="number"
              step="0.01"
              {...register('recovered_value', { valueAsNumber: true })}
              className="w-full px-4 py-2 border border-neutral-300 rounded-xl focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500 outline-none transition-all"
            />
            {errors.recovered_value && <p className="text-red-500 text-xs mt-1">{errors.recovered_value.message}</p>}
          </div>

          <div>
            <label className="block text-sm font-medium text-neutral-700 mb-1">Notes (Optional)</label>
            <textarea
              {...register('notes')}
              rows={3}
              className="w-full px-4 py-2 border border-neutral-300 rounded-xl focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500 outline-none transition-all resize-none"
              placeholder="e.g., Donated to local food bank"
            />
          </div>

          <div className="pt-4 border-t border-neutral-100 flex justify-end gap-3">
            <button
              type="submit"
              disabled={isSubmitting}
              className="w-full px-6 py-3 bg-emerald-600 hover:bg-emerald-700 text-white font-medium rounded-xl transition-colors shadow-sm disabled:opacity-50 flex items-center justify-center gap-2"
            >
              {isSubmitting && <Loader2 className="w-4 h-4 animate-spin" />}
              Complete Action
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}
